```
Enter the number of identifiers: 5
Enter the probabilities for a succesfull search: 3
4
3
2
4
Enter the probablities for an unsuccesfull search: 4
4
5
4
5
4
c[0][5] = 103
w[0][5] = 42
r[0][5] = 3
Minimum cost of the BST is: 103
root: May
```